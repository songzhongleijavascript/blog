import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { posts } from '../services/api';

function PostList({ user }) {
  const [postList, setPostList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await posts.getAll();
      setPostList(response.data);
    } catch (error) {
      console.error('获取文章失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('确定要删除这篇文章吗？')) {
      try {
        await posts.delete(id);
        fetchPosts();
      } catch (error) {
        console.error('删除失败:', error);
      }
    }
  };

  if (loading) return <div className="loading">加载中...</div>;

  return (
    <div className="post-list">
      <h1>最新文章</h1>
      {postList.length === 0 ? (
        <p className="no-posts">暂无文章</p>
      ) : (
        postList.map(post => (
          <div key={post.id} className="post-card">
            <h2>
              <Link to={`/post/${post.id}`}>{post.title}</Link>
            </h2>
            <div className="post-meta">
              <span>作者：{post.author.username}</span>
              <span>发布于：{new Date(post.created_at).toLocaleDateString()}</span>
            </div>
            <p className="post-excerpt">
              {post.content.length > 200
                ? post.content.substring(0, 200) + '...'
                : post.content}
            </p>
            <div className="post-actions">
              <Link to={`/post/${post.id}`} className="btn-secondary">
                阅读全文
              </Link>
              {user && user.id === post.author_id && (
                <>
                  <Link to={`/edit/${post.id}`} className="btn-edit">
                    编辑
                  </Link>
                  <button
                    onClick={() => handleDelete(post.id)}
                    className="btn-delete"
                  >
                    删除
                  </button>
                </>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default PostList;