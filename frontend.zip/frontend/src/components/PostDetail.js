import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { posts, comments } from '../services/api';

function PostDetail({ user }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [commentList, setCommentList] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPost();
    fetchComments();
  }, [id]);

  const fetchPost = async () => {
    try {
      const response = await posts.getOne(id);
      setPost(response.data);
    } catch (error) {
      console.error('获取文章失败:', error);
    }
  };

  const fetchComments = async () => {
    try {
      const response = await comments.getByPost(id);
      setCommentList(response.data);
    } catch (error) {
      console.error('获取评论失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    try {
      await comments.create({
        content: newComment,
        post_id: parseInt(id),
      });
      setNewComment('');
      fetchComments();
    } catch (error) {
      console.error('发表评论失败:', error);
    }
  };

  const handleDeleteComment = async (commentId) => {
    if (window.confirm('确定要删除这条评论吗？')) {
      try {
        await comments.delete(commentId);
        fetchComments();
      } catch (error) {
        console.error('删除评论失败:', error);
      }
    }
  };

  const handleDeletePost = async () => {
    if (window.confirm('确定要删除这篇文章吗？')) {
      try {
        await posts.delete(id);
        navigate('/');
      } catch (error) {
        console.error('删除文章失败:', error);
      }
    }
  };

  if (loading) return <div className="loading">加载中...</div>;
  if (!post) return <div className="not-found">文章不存在</div>;

  return (
    <div className="post-detail">
      <article className="post-content">
        <h1>{post.title}</h1>
        <div className="post-meta">
          <span>作者：{post.author.username}</span>
          <span>发布时间：{new Date(post.created_at).toLocaleString()}</span>
          {post.updated_at && (
            <span>最后更新：{new Date(post.updated_at).toLocaleString()}</span>
          )}
        </div>
        <div className="content">
          {post.content.split('\n').map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
        {user && user.id === post.author_id && (
          <div className="post-actions">
            <Link to={`/edit/${post.id}`} className="btn-edit">编辑文章</Link>
            <button onClick={handleDeletePost} className="btn-delete">删除文章</button>
          </div>
        )}
      </article>

      <section className="comments-section">
        <h2>评论 ({commentList.length})</h2>

        {user ? (
          <form onSubmit={handleCommentSubmit} className="comment-form">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="写下你的评论..."
              rows="3"
              required
            />
            <button type="submit" className="btn-primary">发表评论</button>
          </form>
        ) : (
          <p className="login-to-comment">
            <Link to="/login">登录</Link>后发表评论
          </p>
        )}

        <div className="comments-list">
          {commentList.length === 0 ? (
            <p className="no-comments">暂无评论</p>
          ) : (
            commentList.map(comment => (
              <div key={comment.id} className="comment">
                <div className="comment-header">
                  <span className="comment-author">{comment.author.username}</span>
                  <span className="comment-date">
                    {new Date(comment.created_at).toLocaleString()}
                  </span>
                </div>
                <p className="comment-content">{comment.content}</p>
                {user && user.id === comment.author_id && (
                  <button
                    onClick={() => handleDeleteComment(comment.id)}
                    className="btn-delete-comment"
                  >
                    删除
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}

export default PostDetail;