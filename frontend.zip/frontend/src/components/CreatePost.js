import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { posts } from '../services/api';

function CreatePost() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    content: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (id) {
      fetchPost();
    }
  }, [id]);

  const fetchPost = async () => {
    try {
      const response = await posts.getOne(id);
      setFormData({
        title: response.data.title,
        content: response.data.content,
      });
    } catch (error) {
      console.error('获取文章失败:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (id) {
        await posts.update(id, formData);
      } else {
        await posts.create(formData);
      }
      navigate('/');
    } catch (err) {
      setError(id ? '更新文章失败' : '创建文章失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="create-post">
      <h1>{id ? '编辑文章' : '写新文章'}</h1>
      {error && <div className="error">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>标题</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            maxLength="200"
          />
        </div>
        <div className="form-group">
          <label>内容</label>
          <textarea
            name="content"
            value={formData.content}
            onChange={handleChange}
            required
            rows="10"
          />
        </div>
        <div className="form-actions">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="btn-secondary"
          >
            取消
          </button>
          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? '提交中...' : (id ? '更新' : '发布')}
          </button>
        </div>
      </form>
    </div>
  );
}

export default CreatePost;