import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Navbar({ user, onLogout }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="nav-logo">
          博客系统
        </Link>
        <div className="nav-menu">
          <Link to="/" className="nav-link">首页</Link>
          {user ? (
            <>
              <Link to="/create" className="nav-link">写文章</Link>
              <span className="nav-user">欢迎, {user.username}</span>
              <button onClick={handleLogout} className="nav-link logout-btn">
                退出
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="nav-link">登录</Link>
              <Link to="/register" className="nav-link">注册</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;