import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { auth } from '../services/api';

function Login({ onLogin }) {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await auth.login(formData.username, formData.password);
      localStorage.setItem('token', response.data.access_token);

      // 获取用户信息
      const userResponse = await auth.getCurrentUser();
      onLogin(userResponse.data);
      navigate('/');
    } catch (err) {
      setError('用户名或密码错误');
    }
  };

  return (
    <div className="auth-form">
      <h2>登录</h2>
      {error && <div className="error">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>用户名</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>密码</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn-primary">登录</button>
      </form>
      <p className="auth-link">
        还没有账号？ <Link to="/register">立即注册</Link>
      </p>
    </div>
  );
}

export default Login;